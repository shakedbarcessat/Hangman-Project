import random
def main():
    HANGMAN_ASCII_ART = " _    _\n| |  | |\n| |__| | __ _ _ __   __ _ _ __ ___   __ _ _ __\n|  __  |/ _' | '_ \ / _' | '_ ' _ \ / _' | '_ \ \n| |  | | (_| | | | | (_| | | | | | | (_| | | | |\n|_|  |_|\__,_|_| |_|\__, |_| |_| |_|\__,_|_| |_|\n                     __/ |\n                    |___/\n"
    print("Welcome to the game Hangman")
    print(HANGMAN_ASCII_ART)
    MAX_TRIES = random.randint(5,10)
    print(MAX_TRIES)
    input_file = open("words.txt", "w")
    input_file.write(input("enter a string "))
    input_file.close()
    w = int(input("please type index"))
    count, word = choose_word("words.txt", w)
    print_hangman(0)
    print('-' * len(word))
    old_letters = []
    num_of_tries = 0
    letter = input("Guess a letter: ")
    sign = try_update_letter_guessed(letter, old_letters)
    if (sign == False):
        letter = input("input a letter")
        while (is_valid_input(letter) == False):
            letter = input("input a letter ")
        sign = True
    if (sign == True):
        if (letter in word):
            print(show_hidden_word(word, old_letters))
        else:
            print("):")
            print_hangman(num_of_tries + 1)
    num_of_tries = num_of_tries + 1

    while (num_of_tries < 6 and check_win(word, old_letters) == False):
        letter = input("Guess a letter: ")
        sign = try_update_letter_guessed(letter, old_letters)
        if (sign == False):
            letter = input("input a letter")
            while (is_valid_input(letter) == False):
                letter = input("input a letter")
            sign = True
        if (sign == True):
            if (letter in word):
                print(show_hidden_word(word, old_letters))
            else:
                print("):")
                print_hangman(num_of_tries + 1)
        num_of_tries = num_of_tries + 1
    if (num_of_tries == 6 or num_of_tries > 6):
        print("LOSE")
    else:
        print("WIN")


def choose_word(file_path, index):
    """The function finds how many unrepeated words are in the file_path and finds the word that located in the index that we got
  :param file_path: file_path value
  :param index: index value
  :type file_path: txt
  :type index: int
  :return: The number of the unrepeated words that are in the file_path and a word that located in the index we got as a param.
  :rtype: tuple
  """
    file1 = open(file_path, "r")
    txt = file1.read()
    words = txt.split()
    print(words)
    count = len(set(words))
    word = words[(index - 1) % len(words)]
    return count, word


def show_hidden_word(secret_word, old_letters_guessed):
    """The function show the letters that are in the list old_letters_guessed which also appear in the string secret_word in the right location and the missing lettersas lines "-"
  :param secret_word: secret_word value
  :param old_letters_guessed: old_letters_guessed value
  :type secret_word: string
  :type old_letters_guessed: list
  :return: A string that is made from lines and letters.
  :rtype: string
  """
    str = ""
    for char in secret_word:
        if (char in old_letters_guessed):
            str = str + char
        else:
            str = str + "-"
    return str


def print_hangman(num_of_tries):
    """The function prints the value of the key. The key worth to the number of tries.
  :param num_of_tries: num_of_tries value
  :type num_of_tries: int
  """
    HANGMAN_PHOTOS = {0: 'x-------x', 1: 'x-------x\n|\n|\n|\n|\n|', 2: 'x-------x\n|       |\n|       0\n|\n|\n|',
                      3: 'x-------x\n|       |\n|       0\n|       |\n|\n|',
                      4: 'x-------x\n|       |\n|       0\n|      /|\ \n|\n|',
                      5: 'x-------x\n|       |\n|       0\n|      /|\ \n|      /\n|',
                      6: 'x-------x\n|       |\n|       0\n|      /|\ \n|      / \ \n|'}
    print(HANGMAN_PHOTOS.pop(num_of_tries))


def check_win(secret_word, old_letters_guessed):
    """The function is checking if the player won the game or not.
  :param secret_word: secret_word value
  :param old_letters_guessed: old_letters_guessed value
  :type secret_word: string
  :type old_letters_guessed: list
  :return: True if all the letters in the secret_word appears in the list old_letters_guessed
  :rtype: bool
  """
    for char in secret_word:
        if (not (char in old_letters_guessed)):
            return False
    return True


def try_update_letter_guessed(letter_guessed, old_letters_guessed):
    """The function adds the letter_guessed to the list old_letters_guessed if the letter followed the conditions.
       If not, it sorts the list, print "x" and print the list old_letters_guessed
  :param letter_guessed: letter_guessed value
  :param old_letters_guessed: old_letters_guessed value
  :type letter_guessed: string
  :type old_letters_guessed: list
  :return:True if the string "letter_guessed" is following the rules, otherwise False
  """
    sign = check_valid_input(letter_guessed, old_letters_guessed)
    if (sign == True):
        old_letters_guessed.append(letter_guessed)
        return True
    else:
        print("x")
        old_letters_guessed.sort()
        print(old_letters_guessed)
        return False


def check_valid_input(letter_guessed, old_letters_guessed):
    """The function is checking if the string "letter_guessed" follows the conditions.
  :param letter_guessed: letter_guessed value
  :param old_letters_guessed: old_letters_guessed value
  :type letter_guessed: string
  :type old_letters_guessed: list
  :return: True if the string "letter_guessed" is following the rules, otherwise False
  :rtype: bool
  """
    sign = 0
    if ((len(letter_guessed)) > 1):
        for char in letter_guessed:
            if (not char.isalpha()):
                print("E3")
                sign = 1
        if (sign == 0):
            print("E1")
    elif (not letter_guessed.isalpha()):
        print("E2")
    else:
        print(letter_guessed.lower())
        if (letter_guessed in old_letters_guessed):
            return False
        else:
            return True
    return False


def is_valid_input(letter_guessed):
    """The function is checking if the string "letter_guessed" follows the conditions.
     :param: letter_guessed: letter_guessed value
     :type: letter_guessed: string
     :return: True if the string "letter_guessed" is following the rules, otherwise False
     :rtype: bool
     """
    sign = 0
    if ((len(letter_guessed)) > 1):
        for char in letter_guessed:
            if (not char.isalpha()):
                print("E3")
                sign = 1
        if (sign == 0):
            print("E1")
    elif (not letter_guessed.isalpha()):
        print("E2")
    else:
        print(letter_guessed.lower())
        return True
    return False


if __name__ == '__main__':
    main()
