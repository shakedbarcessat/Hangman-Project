def my_mp4_playlist(file_path, new_song):
    """הפונקציה כותבת לקובץ את המחרוזת המייצגת שם של שיר חדש (new_song) במקום שם השיר המופיע בשורה השלישית בקובץ (אם הקובץ מכיל פחות משלוש שורות, כתבו לקובץ שורות ריקות כך ששם השיר ייכתב בשורה השלישית).
הפונקציה מדפיסה את תוכן הקובץ לאחר השינוי שבוצע.
      :param file_path: path file
      :param new_song: name of the new song
      :type file_path: string
      :type new_song: string
      """
    count = 0
    with open(file_path) as file:
        for line in file:
            count += 1
    file_open = open(file_path, "r")
    content = file_open.read()
    if count < 3:
        file_open = open(file_path, "w")
        content = "123\n234\n" + new_song
        file_open.write(content)
    else:
        content = content.split("\n")
        add = content[2].split(';')
        add[0] = new_song
        content[2] = ';'.join(str(e) for e in add)
        file_open = open(file_path, "w")
        for item in content:
            file_open.write(str(item) + "\n")


my_mp4_playlist(r"C:\Users\Shaked\Desktop\check\s1.txt", "shaked")
