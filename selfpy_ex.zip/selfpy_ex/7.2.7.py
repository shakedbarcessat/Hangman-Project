def arrow(my_char, max_length):
    """The function prints an arrow with the my_char, max_length times
      :param my_char: char to repeat
      :param max_length: times to repeat
      :type my_char: char
      :type max_length: int
      """
    for i in range(max_length + 1):
        print(my_char * i)
    for i in range(max_length - 1, 0, -1):
        print(my_char * i)


"""
print(arrow('*', 5))
"""
