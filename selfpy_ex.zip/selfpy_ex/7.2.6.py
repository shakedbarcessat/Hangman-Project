def print_products(products):
    for prod in products:
        print(prod)


def print_num_products(products):
    print(len(products))


def print_is_found(prod_name, products):
    print(str(prod_name).lower() in products)


def print_count_found(prod_name, products):
    print(list(products).count(str(prod_name).lower()))


def delete_prod(prod_name, products):
    products.remove(prod_name.lower())


def add_prod(prod_name, products):
    products.append(prod_name.lower())


def print_invalid_products(products):
    for prod in products:
        if len(prod) < 3 or not str(prod).isalpha():
            print(prod)


def delete_duplicates(products):
    li = []
    for prod in products:
        if prod not in li:
            li.append(prod)
    print(li)
    return li


def main():
    products = input("enter a list of products ")
    products = products.lower().split(',')
    print("select an option please: ")
    print("1. print the list of products")
    print("2. print the number of products in the list")
    print("3. check if a product is on the list, enter name of product")
    print("4. check the appearance of a product, enter name of product")
    print("5. remove a product from the list, enter name of product")
    print("6. add a product to the list, enter name of product")
    print("7. print invalid products")
    print("8. remove duplicates")
    print("9. Exit")
    choose = int(input("enter a choice "))
    while choose != 9:
        if choose == 1:
            print_products(products)
        elif choose == 2:
            print_num_products(products)
        elif choose == 3:
            print_is_found(input("enter a product name "), products)
        elif choose == 4:
            print_count_found(input("enter a product name "), products)
        elif choose == 5:
            delete_prod(input("enter a product name "), products)
        elif choose == 6:
            add_prod(input("enter a product name "), products)
        elif choose == 7:
            print_invalid_products(products)
        elif choose == 8:
            products = delete_duplicates(products)
        choose = int(input("enter a choice "))


if __name__ == '__main__':
    main()
