def mult_tuple(tuple1, tuple2):
    """The function returns all the cases of pairs
      :param tuple1: first tuple
      :param tuple2: second tuple
      :type tuple1: tuple
      :type tuple2: tuple
      :return: returns all the cases of pairs
      :rtype: tuple of tuples
      """
    tuple_new = []
    for elem in tuple1:
        for elem2 in tuple2:
            tuple_new.append([elem, elem2])
            tuple_new.append([elem2, elem])
    return tuple([tuple(lst) for lst in tuple_new])


first_tuple = (1, 2)
second_tuple = (4, 5)
print(mult_tuple(first_tuple, second_tuple))
