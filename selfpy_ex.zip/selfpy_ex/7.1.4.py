def squared_numbers(start, stop):
    """The function creates list that have squares of all the numbers between start and stop
      :param start: start num
      :param stop: end num
      :type start: int
      :type stop: int
      :return: returns list that have squares of all the numbers between start and stop
      :rtype: list
      """
    li = []
    while start <= stop:
        li.append(start * start)
        start += 1
    return li


"""
print(squared_numbers(4, 8))
print(squared_numbers(-3, 3))
"""
