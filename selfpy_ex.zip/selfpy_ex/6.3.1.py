def are_lists_equal(list1, list2):
    """The function checks if the lists have the same elements with different order
  :param list1: list of elements int and float
  :param list2: list of elements int and float
  :type list1: list
  :type list2: list
  :return: returns true if the lists have the same elements with different order
  :rtype: boolean
  """
    return sorted(list1) == sorted(list2)


"""
list1 = [0.6, 1, 2, 3]
list2 = [3, 2, 0.6, 1]
list3 = [9, 0, 5, 10.5]
print(are_lists_equal(list1, list2))
print(are_lists_equal(list1, list3))
"""
