def main():
    print("shaked")

def choose_word(file_path, index):
    """The function finds how many unrepeated words are in the file_path and finds the word that located in the index that we got
  :param file_path: file_path value
  :param index: index value
  :type file_path: txt
  :type index: int
  :return: The number of the unrepeated words that are in the file_path and a word that located in the index we got as a param.
  :rtype: tuple
  """


if __name__ == '__main__':
    main()
