def extend_list_x(list_x, list_y):
    """The function merges list_y and then list_x
    and the last element
  :param list_x: list of elements
  :param list_y: list of elements
  :type list_x: list
  :type list_y: list

  :return: returns the merge of them when list_y and then list_x
  :rtype: list
  """
    return [*list_y, *list_x]


"""
x = [4, 5, 6]
y = [1, 2, 3]
print(extend_list_x(x, y))
"""
