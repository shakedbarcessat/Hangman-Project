def chocolate_maker(small, big, x):
    """The function checks if can make row in the length of x
  :param small: how many cubes with length of 1
  :param big: how many cubes with length of 5
  :param x: the length
  :type small: int
  :type small: int
  :type small: int
  :return: true if can make row in the length of x, else false
  :rtype: boolean
  """
    if x > (small + big * 5) or x % 5 > small:
        return False
    return True


"""
print(chocolate_maker(3, 1, 8))
print(chocolate_maker(3, 1, 9))
print(chocolate_maker(3, 2, 10))
print(chocolate_maker(1, 2, 9))
"""
