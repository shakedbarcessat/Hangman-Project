st = input("Please enter a string: ")
if len(st) > 0:
    char = st[0]  # the first char
    st_after = st[1::].replace(char, 'e')  # replacing every occurence of the first char with 'e'
    print(char + st_after)  # adding the first char to the string
else:
    print("error")  # length 0
