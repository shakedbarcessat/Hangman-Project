st = input("Insert the temperature you would like to convert: ")
if st[-1] == 'F' or st[-1] == 'f':  # convert Fahrenheit to Celsius
    print(str((5 * float(st[:-1]) - 160) / 9) + 'C')

elif st[-1] == 'C' or st[-1] == 'c':  # convert Celsius to Fahrenheit
    print(str((9 * float(st[:-1]) + 160) / 5) + 'C')

else:
    print("error")
