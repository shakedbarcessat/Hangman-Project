def sequence_del(my_str):
    """The function creates a string that deletes letters in a row
      :param my_str: string of letters
      :type my_str: string
      :return: returns a string that deletes letters in a row
      :rtype: string
      """
    li = []
    for ch in my_str:
        if not li or ch != li[-1]:
            li.append(ch)
    return ''.join(li)


"""
print(sequence_del("ppyyyyythhhhhooonnnnn"))
print(sequence_del("SSSSsssshhhh"))
print(sequence_del("Heeyyy   yyouuuu!!!"))
"""
