import calendar

week_days = ['Monday', "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]  # days of the week
date = input("Enter a date: ")
date = date.split('/')
print(week_days[calendar.weekday(int(date[2]), int(date[1]), int(date[0]))])
