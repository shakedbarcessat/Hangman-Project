def shift_left(my_list):
    """The function returns my_list with one shift left
  :param my_list: list with the length of 3
  :type my_list: list
  :return: returns my_list with one shift left
  :rtype: list
  """
    return [my_list[1], my_list[2], my_list[0]]


"""
print(shift_left([0, 1, 2]))
print(shift_left(['monkey', 2.0, 1]))
"""