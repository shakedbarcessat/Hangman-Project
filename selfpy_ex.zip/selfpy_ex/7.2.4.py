def seven_boom(end_number):
    """The function creates a list of the numbers 0 to end_number with the game seven boom
      :param my_str: end_number
      :type my_str: int
      :return: returns a list of the numbers 0 to end_number with the game seven boom
      :rtype: list
      """
    li_boom = []
    for num in range(end_number + 1):
        if num % 7 == 0 or '7' in str(num):
            li_boom.append("BOOM")
        else:
            li_boom.append(num)
    return li_boom


"""
print(seven_boom(17))
"""
