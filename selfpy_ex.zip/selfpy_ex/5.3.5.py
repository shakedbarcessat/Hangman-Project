def distance(num1, num2, num3):
    """The function checks if num2 or num3 is far absolut by 1 and
    if num2 or num3 is far absolut more than 1
  :param num1: first num
  :param num2: second num
  :param num3: third num
  :type num1: int
  :type num2: int
  :type num3: int
  :return: true if the condition exists, otherwise false
  :rtype: boolean
  """
    if ((abs(num1 - num2) == 1) or (abs(num1 - num3) == 1)) and ((abs(num1 - num2) > 1) or (abs(num1 - num3) > 1)):
        return True
    return False


"""
print(distance(1, 2, 10))
print(distance(4, 5, 3))
"""
