def my_mp3_playlist(file_path):
    """The function manages a tuple of 3 elements:
    האיבר הראשון הוא מחרוזת המייצגת את שם השיר הארוך ביותר בקובץ (הכוונה היא לשיר הארוך ביותר, הניחו שכל האורכים שונים).
האיבר השני הוא מספר המייצג את מספר השירים שהקובץ מכיל.
האיבר השלישי הוא מחרוזת המייצגת את שם המבצע שמופיע בקובץ מספר הפעמים הגדול ביותר (הניחו שיש רק אחד כזה).
      :param file_path: file path
      :type file_path: string
      :return: returns a string that deletes letters in a row
      :rtype: string
      """
    count = 0
    times = []
    authors = []
    with open(file_path) as file:
        for line in file:
            count += 1
            times.append(line.split(';')[2])
            authors.append(line.split(';')[1])

    times.sort()
    max_time = times[-1]
    max_name = ""
    with open(file_path) as file:
        for line in file:
            if line.split(';')[2] == max_time:
                max_name = line.split(';')[0]

    return tuple([max_name, count, max(authors, key=authors.count)])


print(my_mp3_playlist(r"C:\Users\Shaked\Desktop\check\s1.txt"))
