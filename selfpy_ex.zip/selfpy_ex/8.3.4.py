def inverse_dict(my_dict):
    """The function creates an opposite diction - the values are keys and keys are values
      :param my_dict: dictionary
      :type my_dict: dictionary
      :return: returns an opposite diction - the values are keys and keys are values
      :rtype: diction
      """
    diction = {}
    for key, value in my_dict.items():
        if value in diction:
            diction[value].append(key)
        else:
            diction[value] = [key]
    for key in diction.keys():
        diction[key].sort()
    return diction


course_dict = {'I': 3, 'love': 3, 'self.py!': 2}
print(inverse_dict(course_dict))
