def func(num1, num2):
    """The function calculates num1 multiply num2
  :param num1: num 1
  :param num2: num 2
  :type num1: float
  :type num2: float
  :return: num1 multiply num2
  :rtype: float
  """
    return float(num1 * num2)


def main():
    # Call the function func
    print(func(2, 5.5))
if __name__ == "__main__":
    main()