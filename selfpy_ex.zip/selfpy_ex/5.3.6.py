def fix_age(age):
    """The function calc the right age for age
  :param age: age
  :type age: int
  :return: the right age
  :rtype: int
  """
    if age in [13, 14, 17, 18, 19]:
        return 0
    return age


def filter_teens(a=13, b=13, c=13):
    """The function calculates the sum of a, b, c
  :param a: age 1
  :param b: age 2
  :param c: age 3
  :type a: int
  :type b: int
  :type c: int
  :return: the sum of a, b, c
  :rtype: int
  """
    return fix_age(a) + fix_age(b) + fix_age(c)


"""
print(filter_teens())
print(filter_teens(1, 2, 3))
print(filter_teens(2, 13, 1))
print(filter_teens(2, 1, 15))
"""
