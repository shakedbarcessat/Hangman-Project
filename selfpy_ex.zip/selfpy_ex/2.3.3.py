num = int(input("Enter three digits (each digit for one pig):"))  # input the number
sum = num % 10 + int(num / 10 % 10) + int(num / 100)  # calc the sum of digits
print(sum)  # print the sum
print(int(sum / 3))
print(sum % 3)
print(sum % 3 == 0)  # print if the num is divided equal with the pigs
