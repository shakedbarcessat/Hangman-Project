def sort_prices(list_of_tuples):
    """The function creates a list of tuples sorted by the price, from big to small
      :param list_of_tuples: list of tuples [('item', 'price'), ('item', 'price'), ('item', 'price')]
      :type list_of_tuples: list of tuples
      :return: returns a list of tuples sorted by the price, from big to small
      :rtype: string
      """
    return sorted(list_of_tuples, key=lambda tup: tup[1], reverse=True)


"""
products = [('milk', '5.5'), ('candy', '2.5'), ('bread', '9.0')]
print(sort_prices(products))
"""