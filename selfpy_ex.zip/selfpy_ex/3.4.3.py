st = input("Please enter a string: ")
print(st[0:int(len(st) / 2)].lower() + (st[int(len(st) / 2):]).upper())  # first half lower, second half upper
