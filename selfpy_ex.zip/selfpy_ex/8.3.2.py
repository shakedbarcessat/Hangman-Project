diction = {"first_name": "Mariah", "last_name": "Carey",
           "birth_date": "27.03.1970", "hobbies": ["Sing", "Compose", "Act"]}

choose = int(input("enter a choice from 1 to 7: "))
if choose == 1:
    print(diction["last_name"])
if choose == 2:
    print(diction["birth_date"].split('.')[1])
if choose == 3:
    print(len(diction["hobbies"]))
if choose == 4:
    print((diction["hobbies"])[-1])
if choose == 5:
    diction["hobbies"].append("Cooking")
if choose == 6:
    l = [diction["birth_date"].split('.')]
    print(tuple([tuple(lst) for lst in l]))
if choose == 7:
    diction.update({"age": "17"})
    print(diction["age"])
