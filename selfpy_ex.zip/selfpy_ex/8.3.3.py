def count_chars(my_str):
    """The function creates a dictionary when the key is a char in the string and the value is the times it occurs
      :param my_str: a sentence
      :type my_str: string
      :return: returns a dictionary when the key is a char in the string and the value is the times it occurs
      :rtype: dictionary
      """
    chars = []
    diction = {}
    for i in my_str:
        if i not in chars and i != " ":
            diction.update({i: my_str.count(i)})
    return diction


magic_str = "abra cadabra"
print(count_chars(magic_str))
