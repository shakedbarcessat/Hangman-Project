def edit_text(file_path, action):
    """The function manages the request
      :param file_path: file path
      :param action: action to choose
      :type file_path: string
      :type action: string
      """
    file_open = open(file_path, "r")
    content = file_open.read()
    if action == "sort":
        content = content.split(' ')
        li = []
        for elem in content:
            if elem not in li:
                li.append(elem)
        li.sort()
        print(li)

    elif action == "rev":
        with open(file_path) as file:
            for line in file:
                print(line[::-1])

    elif action == "last":
        num = int(input("enter num for how many rows wants to print"))
        li = []
        with open(file_path) as file:
            for line in file:
                li.append(line)
        for i in range(num):
            print(li[-1])
            li.remove(li[-1])
    file_open.close()


def main():
    path = input("input file path: ")
    choose = int(input("enter a choice rev, sort or last: "))
    edit_text(path, choose)


if __name__ == '__main__':
    main()

# edit_text(r"C:\Users\Shaked\Desktop\check\s1.txt", "last")
