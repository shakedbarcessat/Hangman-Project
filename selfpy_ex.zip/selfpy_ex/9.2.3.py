def who_is_missing(file_name):
    """The function returns the missing number and writes it to the file
      :param file_name: file path
      :type file_name: string
      :return: returns the missing number
      :rtype: int
      """
    file_open = open(file_name, "r")
    content1 = file_open.read()
    content1 = content1.split(',')
    content1 = [int(x) for x in content1]
    content1.sort()
    for i in range(1, content1[-1]):
        if i not in content1:
            file_open = open(file_name, "w")
            file_open.write(str(i))
            return i
    file_open.close()


print(who_is_missing(r"C:\Users\Shaked\Desktop\check\s1.txt"))
