def numbers_letters_count(my_str):
    """The function creates a list when the first element is number of digits and the second is number of letters
      :param my_str: string as an input
      :type my_str: string
      :return: returns a list when the first element is number of digits and the second is number of letters
      :rtype: list
      """
    count_digits = 0  # count how many digits
    for ch in my_str:
        if ch.isnumeric():
            count_digits += 1
    return [count_digits, len(my_str) - count_digits]


"""
print(numbers_letters_count("Python 3.6.3"))
"""
