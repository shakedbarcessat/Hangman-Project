def sort_anagrams(list_of_strings):
    """הפונקציה מקבלת כפרמטר רשימת מחרוזות, כך שכל מחרוזת היא מילה אחת (ללא רווחים).
      :param list_of_strings: list of anagrams
      :type list_of_strings: list
      :return: הפונקציה מחזירה רשימה של אותן מחרוזות שהועברו, אך באופן הבא: הרשימה מחולקת לרשימות כך שכל רשימה "פנימית" מורכבת ממילים שהן אנגרמות אחת של השנייה
      :rtype: list of lists
      """

    anagrams_check = {}
    for letters in list_of_strings:
        key = ''.join(sorted(letters))
        if key in anagrams_check:
            anagrams_check[key].append(letters)
        else:
            anagrams_check[key] = [letters]
    return list(anagrams_check.values())

list_of_words = ['deltas', 'retainers', 'desalt', 'pants', 'slated', 'generating', 'ternaries', 'smelters', 'termless',
                 'salted', 'staled', 'greatening', 'lasted', 'resmelts']
print(sort_anagrams(list_of_words))

