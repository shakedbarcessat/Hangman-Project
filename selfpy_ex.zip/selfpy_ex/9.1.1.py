def are_files_equal(file1, file2):
    """The function checks if the files contain the same information
      :param file1: path file1
      :param file2: path file2
      :type file1: string
      :type file2: string
      :return: returns true if the files contain the same information, else false
      :rtype: boolean
      """
    file1_open = open(file1, "r")
    file2_open = open(file2, "r")
    content1 = file1_open.read()
    content2 = file2_open.read()
    if content2 == content1:
        return True
    return False


"""
print(are_files_equal(r"C:\Users\Shaked\Desktop\check\s1.txt",
                      r"C:\Users\Shaked\Desktop\check\s2.txt"))
"""
