def is_greater(my_list, n):
    """The function creates new list that contains the numbers in my_list that are bigger than n
      :param my_list: list of elements
      :param n: number
      :type my_list: list
      :type n: int
      :return: returns a new list that contains the numbers in my_list that are bigger than n
      :rtype: list
      """
    li = []
    for element in my_list:
        if element > n:
            li.append(element)
    return li


"""
result = is_greater([1, 30, 25, 60, 27, 28], 28)
print(result)
"""
