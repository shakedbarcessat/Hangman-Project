def format_list(my_list):
    """The function returns string with the elements in the even places
    and the last element
  :param my_list: list
  :type my_list: list
  :return: returns string with the elements in the even places
    and the last element
  :rtype: string
  """
    new_list = my_list[::2]
    st = ', '.join(new_list)
    return st + " and " + my_list[-1]


"""
my_list = ["hydrogen", "helium", "lithium", "beryllium", "boron", "magnesium"]
print(format_list(my_list))
"""
