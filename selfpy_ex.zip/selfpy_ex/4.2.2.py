st = input("enter a word: ")
st = st.lower().replace(" ", "")  # lower letters and no spaces
if st == st[::-1]:
    print("OK")
else:
    print("NOT")
