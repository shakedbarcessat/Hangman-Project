def last_early(my_str):
    """The function checks if the last char in the my_str appears again in the string
  :param my_str: string value
  :type my_str: string
  :return: true if the last char appears again in the string, otherwise false
  :rtype: boolean
  """
    my_str = my_str.lower()
    char = my_str[-1]
    my_str = my_str[:-2]
    if (str(my_str).find(char)) == -1:
        return False
    return True


"""
print(last_early("happy birthday"))
print(last_early("best of luck"))
print(last_early("Wow"))
print(last_early("X"))
"""
