def longest(my_list):
    """The function looks for the longest string in my_list
  :param my_list: list of strings
  :type my_list: list
  :return: returns the longest string in my_list
  :rtype: string
  """
    return sorted(my_list, key=len)[-1]


"""
list1 = ["111", "234", "2000", "goru", "birthday", "09"]
print(longest(list1))
"""
