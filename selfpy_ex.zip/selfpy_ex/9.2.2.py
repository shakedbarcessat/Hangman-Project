def copy_file_content(source, destination):
    """The function copies source contant to destination
      :param source: path file1- the source
      :param destination: path file2 - the destination
      :type source: string
      :type destination: string
      """
    file_open = open(source, "r")
    content1 = file_open.read()
    file_open = open(destination, "w")
    file_open.write(content1)
    file_open.close()


copy_file_content(r"C:\Users\Shaked\Desktop\check\s1.txt",
                  r"C:\Users\Shaked\Desktop\check\s2.txt")
